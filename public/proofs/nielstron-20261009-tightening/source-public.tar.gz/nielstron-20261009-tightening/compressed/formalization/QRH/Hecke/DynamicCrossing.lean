import OAI.NumberTheory.DirichletL.Hecke.DetectorRowCountCrossing
import QRH.Adaptive
import QRH.DynamicLoss

namespace OAI

noncomputable section
namespace SevenEighths.QRHDetectorRowCount
open QRH.Certificate (c)
open QRH (kappa0)


def denominator (x : ℝ) : ℝ := 3-(1+2*c)*x

def primeWeight (x : ℝ) : ℝ := (2-2*c*x)*(1-x)

def crossing (x t : ℝ) : ℝ := ((2-2*c*x)*t-(1-c)*x)/denominator x

def inverseExponent (δ x r : ℝ) : ℝ := 1-δ*(x+(1-x)*r)

def plainExponent (δ x t r : ℝ) : ℝ := 1-δ*(c*x+(2-2*c*x)*(t-r))

def shortExponent (δ x t : ℝ) : ℝ := 1-δ+δ*primeWeight x/denominator x*(3/2-t)

def longExponent (δ t : ℝ) : ℝ := 1-δ+(5/6-δ)*(t-1)

lemma denominator_lower {x : ℝ} (hx : x≤1/2) : 2≤denominator x := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  unfold denominator
  nlinarith [mul_nonneg (show 0≤c by linarith) (show 0≤1/2-x by linarith)]

theorem crossing_bounds {x t : ℝ} (hx : 0≤x) (hx' : x≤1/2)
    (ht : 1≤t) (ht' : t≤3/2) :
    23/37≤crossing x t ∧ crossing x t≤1 ∧
      1/3≤t-crossing x t ∧ t-crossing x t≤1/2 := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hd : 0<denominator x := lt_of_lt_of_le (by norm_num) (denominator_lower hx')
  have hp : 0≤2-2*c*x := by nlinarith
  have hpt := mul_le_mul_of_nonneg_left ht hp
  have hpt' := mul_le_mul_of_nonneg_left ht' hp
  have hm : 0≤1-x := by linarith
  have hmt := mul_le_mul_of_nonneg_left ht hm
  have hmt' := mul_le_mul_of_nonneg_left ht' hm
  have he : t-crossing x t=((1-x)*t+(1-c)*x)/denominator x := by
    unfold crossing
    apply (eq_div_iff hd.ne').mpr
    rw [sub_mul,div_mul_cancel₀ _ hd.ne']
    unfold denominator
    ring
  refine ⟨(le_div_iff₀ hd).mpr ?_,(div_le_iff₀ hd).mpr ?_,?_,?_⟩
  · unfold denominator
    nlinarith
  · unfold denominator
    nlinarith
  · rw [he]
    apply (le_div_iff₀ hd).mpr
    unfold denominator
    nlinarith
  · rw [he]
    apply (div_le_iff₀ hd).mpr
    unfold denominator
    nlinarith



section
variable (δ x t : ℝ) (hd : denominator x≠0)
include δ x t hd

lemma inverse_at_crossing :
    inverseExponent δ x (crossing x t)=shortExponent δ x t := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  unfold inverseExponent crossing shortExponent primeWeight
  field_simp
  unfold denominator
  ring

lemma plain_at_crossing :
    plainExponent δ x t (crossing x t)=shortExponent δ x t := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  unfold plainExponent crossing shortExponent primeWeight
  field_simp
  unfold denominator
  ring

end

theorem selected_short_bound {δ x t r : ℝ} (hδ : 0≤δ) (_hx : 0≤x) (hx' : x≤1/2) :
    (r≤crossing x t → plainExponent δ x t r≤shortExponent δ x t) ∧
      (crossing x t≤r → inverseExponent δ x r≤shortExponent δ x t) := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hd : denominator x≠0 := ne_of_gt (lt_of_lt_of_le (by norm_num) (denominator_lower hx'))
  constructor
  · intro hr
    rw [←plain_at_crossing δ x t hd]
    unfold plainExponent
    have hh := mul_le_mul_of_nonneg_left hr (show 0≤2-2*c*x by nlinarith)
    nlinarith [mul_nonneg hδ (sub_nonneg.mpr hh)]
  · intro hr
    rw [←inverse_at_crossing δ x t hd]
    unfold inverseExponent
    have hh := mul_le_mul_of_nonneg_left hr (show 0≤1-x by linarith)
    nlinarith [mul_nonneg hδ (sub_nonneg.mpr hh)]







lemma short_ge_base {δ x t : ℝ} (hδ : 0≤δ) (_hx : 0≤x) (hx' : x≤1/2)
    (ht : t≤3/2) : 1-δ≤shortExponent δ x t := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hd : 0<denominator x := lt_of_lt_of_le (by norm_num) (denominator_lower hx')
  have hp : 0≤primeWeight x := mul_nonneg (by nlinarith) (by linarith)
  unfold shortExponent
  exact le_add_of_nonneg_right (mul_nonneg (div_nonneg (mul_nonneg hδ hp) hd.le) (by linarith))



theorem capacity_loss {q m Δ γ : ℝ} (_hq : 0≤q) (hq' : q≤5/12)
    (hm : 1/3-γ≤m) (hm' : m≤1/2) (hΔ : 0≤Δ) (hΔ' : Δ≤1/6) (hγ : 0≤γ) :
    2*q*(1-2*m)*(1/(6*kappa0)-1/(6*kappa0+12*Δ))≤(30/169)*Δ+2*γ := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hd : 0<6*kappa0+12*Δ := by linarith
  have hden : (169/9 : ℝ)≤(6*kappa0)*(6*kappa0+12*Δ) := by nlinarith
  have hqmul : q*(1-2*m)≤(5/12)*(1/3+2*γ) :=
    mul_le_mul hq' (by linarith) (by linarith) (by norm_num)
  have hn := mul_le_mul_of_nonneg_right hqmul (show 0≤24*Δ by positivity)
  have hg := mul_le_mul_of_nonneg_left hΔ' (show 0≤24*γ by positivity)
  have he : 2*q*(1-2*m)*(1/(6*kappa0)-1/(6*kappa0+12*Δ)) =
      24*q*(1-2*m)*Δ/((6*kappa0)*(6*kappa0+12*Δ)) := by field_simp; ring
  rw [he]
  apply (div_le_iff₀ (show 0<(6*kappa0)*(6*kappa0+12*Δ) by positivity)).mpr
  have hb := mul_le_mul_of_nonneg_left hden (show 0≤(30/169)*Δ+2*γ by positivity)
  nlinarith

theorem plain_capacity_comparison {δ x Δ t r m γ : ℝ}
    (hδ : 0≤δ) (hδ' : δ≤5/6) (hx : 0≤x) (hx' : x≤1/2)
    (hΔ : 0≤Δ) (hΔ' : Δ≤1/6) (hm : 1/3-γ≤m) (hm' : m≤1/2)
    (hγ : 0≤γ) (hlength : t-r-γ≤m) :
    1-2*δ*m-2*(δ*x)*(1-2*m)/(6*kappa0+12*Δ)≤plainExponent δ x t r+(30/169)*Δ+4*γ := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hq : 0≤δ*x := mul_nonneg hδ hx
  have hq' : δ*x≤5/12 := (mul_le_mul hδ' hx' hx (by norm_num)).trans_eq (by ring)
  have hloss := capacity_loss hq hq' hm hm' hΔ hΔ' hγ
  have hc : 0≤δ*(2-2*c*x) := mul_nonneg hδ (by nlinarith)
  have hc' : δ*(2-2*c*x)≤2 := by
    have hh := mul_le_mul_of_nonneg_right hδ' (show 0≤2-2*c*x by nlinarith)
    nlinarith
  have hlinear := mul_le_mul_of_nonneg_left (show t-r-m≤γ by linarith) hc
  have herror := mul_le_mul_of_nonneg_right hc' hγ
  have hid : (1-2*δ*m-2*(δ*x)*(1-2*m)*(1/(6*kappa0)))-plainExponent δ x t r =
      δ*(2-2*c*x)*(t-r-m) := by unfold plainExponent; dsimp [c]; ring
  have hid' : 1-2*δ*m-2*(δ*x)*(1-2*m)/(6*kappa0+12*Δ) =
      (1-2*δ*m-2*(δ*x)*(1-2*m)*(1/(6*kappa0))) +
      2*(δ*x)*(1-2*m)*(1/(6*kappa0)-1/(6*kappa0+12*Δ)) := by ring
  rw [hid']
  linarith

lemma inverse_zero_capacity {δ r ν : ℝ} (hδ : 0≤δ)
    (hcap : (1-r)/2≤ν) : 1-δ*r≤1-δ+2*δ*ν := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hh := mul_le_mul_of_nonneg_left hcap hδ
  nlinarith

lemma plain_zero_capacity {δ m κ ν : ℝ} (hδ : 0≤δ) (hκ : 0<κ)
    (hκ' : κ≤1) (hν : 0≤ν) (hcap : (1-2*m)/(6*κ)≤ν) :
    1-2*δ*m≤1-δ+6*δ*ν := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hh := (div_le_iff₀ (show 0<6*κ by positivity)).mp hcap
  have hk := mul_le_mul_of_nonneg_right hκ' hν
  have hm : 1-2*m≤6*ν := by nlinarith
  have hh' := mul_le_mul_of_nonneg_left hm hδ
  nlinarith

lemma long_count_bound {δ r t γ : ℝ} (hδ : δ≤5/6) (_hγ : 0≤γ)
    (hr : r≤t+γ) :
    1-5/6+(5/6-δ)*r≤longExponent δ t+(5/6-δ)*γ := by
  have hc0 : (4/9:ℝ) ≤ c := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hc1 : c ≤ (6/13:ℝ) := by norm_num [c, QRH.kappa0, QRH.tightTheta]
  have hk0 : (13/18:ℝ) ≤ kappa0 := by norm_num [kappa0, QRH.tightTheta]

  have hh := mul_le_mul_of_nonneg_left hr (show 0≤5/6-δ by linarith)
  unfold longExponent
  nlinarith

end SevenEighths.QRHDetectorRowCount

end

end OAI
