import QRH.Geometry
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp

/-! Continuous rational exponent certificate. No analytic conclusion is asserted. -/
namespace QRH.Certificate
noncomputable section
open QRH

def c : ℝ := 1 / (3 * kappa0)
def D (x : ℝ) : ℝ := 3 - (1 + 2 * c) * x
def P (x : ℝ) : ℝ := (2 - 2 * c * x) * (1 - x)
def J (δ x : ℝ) : ℝ := (5 / 6 - δ) * D x + δ * P x

def F (δ y : ℝ) : ℝ :=
  -J δ (1 / 2 - y) * ((1 + δ) / 2 - theta - h / 6 -
    (1 + δ) / 2 * ly - ell / 2 + (1 / 2 - y) * δ * ell + h * (1 - δ / 2)) -
    h * (5 / 6 - δ) * δ * P (1 / 2 - y) / 2

def E (δ x : ℝ) : ℝ :=
  (1 + δ) / 2 - theta - h / 6 - (1 + δ) / 2 * ly - ell / 2 + x * δ * ell +
    h * (1 - δ + (5 / 6 - δ) * δ * P x / (2 * J δ x) + δ / 2)

def Av : ℝ := (22980714297137324206149579501325032476327674391 / 97001378465812651372080867785292379000000000000 : ℝ)
def Dv : ℝ := (11468905885308989336086113609703310393394156585533 / 1964953320349168109317400115833592633639660605442000000000000 : ℝ)
def dv : ℝ := (874613174789 / 2250773650422 : ℝ)

theorem Av_pos : 0 < Av := by norm_num [Av]
theorem Dv_margin : (5 / 1000000000000 : ℝ) < Dv := by norm_num [Dv]

theorem square_identity (δ y : ℝ) :
    F δ y = Av * (δ - dv) ^ 2 + Dv +
      y ^ 1 * ((47655690054672811310768671049616269603730713471 / 15714223311461649522277100581217365398000000000000 : ℝ) * (δ - 1 / 3) ^ 0 + (98083233764193411159067931457873357482655419773 / 873012406192313862348727810067631411000000000000 : ℝ) * (δ - 1 / 3) ^ 1 + (66090522357236113351990198326622999204915257847 / 109126550774039232793590976258453926375000000000 : ℝ) * (δ - 1 / 3) ^ 2) +
      y ^ 2 * ((54649633819311606819745866920167325971807856261 / 1309518609288470793523091715101447116500000000000 : ℝ) * (δ - 1 / 3) ^ 0 + (353517731063908646350315646872573955319830302721 / 1309518609288470793523091715101447116500000000000 : ℝ) * (δ - 1 / 3) ^ 1 + (94784414802986912945539023056035988702203366969 / 218253101548078465587181952516907852750000000000 : ℝ) * (δ - 1 / 3) ^ 2) +
      y ^ 3 * ((500515766948 / 30371518573101 : ℝ) * (δ - 1 / 3) ^ 0 + (1001031533896 / 10123839524367 : ℝ) * (δ - 1 / 3) ^ 1 + (500515766948 / 3374613174789 : ℝ) * (δ - 1 / 3) ^ 2) := by
  norm_num [F, J, D, P, c, kappa0, theta, h, lx, ly, M, ell, b, Av, Dv, dv]
  <;> ring

theorem near_margin {δ y : ℝ} (hδ : (1 / 3 : ℝ) ≤ δ) (hy : 0 ≤ y) :
    (5 / 1000000000000 : ℝ) < F δ y := by
  have hu : 0 ≤ δ - 1 / 3 := sub_nonneg.mpr hδ
  have hA := Av_pos.le
  rw [square_identity]
  apply lt_of_lt_of_le Dv_margin
  iterate 3 apply le_trans ?_ (le_add_of_nonneg_right (by positivity))
  exact le_add_of_nonneg_left (by positivity)

theorem bernstein_identity_0 (t v : ℝ) :
    F (t / 4) (v / 2) = (723 / 1000000 : ℝ) +
      (14687513802220459560595971388905665060889381359 / 419045954972310653927389348832463077280000000000 : ℝ) * (1 - t)^2 * (1-v)^3 +
      (15922063544520389829676240908467161461193971359 / 392855582786541238056927514530434134950000000000 : ℝ) * (1 - t)^2 * (3*v*(1-v)^2) +
      (289193326391345581140700138237364190844866363103 / 6285689324584659808910840232486946159200000000000 : ℝ) * (1 - t)^2 * (3*v^2*(1-v)) +
      (15983739928483326080578124965748393 / 310439992132218079530958800000000000 : ℝ) * (1 - t)^2 * v^3 +
      (252159845672480810170150044238372555905316276507 / 20952297748615532696369467441623153864000000000000 : ℝ) * (2*t*(1-t)) * (1-v)^3 +
      (479522203730691386061288853538559856638825406663 / 41904595497231065392738934883246307728000000000000 : ℝ) * (2*t*(1-t)) * (3*v*(1-v)^2) +
      (1338554220201224449914992410449553804912071615781 / 125713786491693196178216804649738923184000000000000 : ℝ) * (2*t*(1-t)) * (3*v^2*(1-v)) +
      (19968081249262566858644094714335309 / 2069599947548120530206392000000000000 : ℝ) * (2*t*(1-t)) * v^3 +
      (32073457698117007637408336919739918878634835737 / 8380919099446213078547786976649261545600000000000 : ℝ) * t^2 * (1-v)^3 +
      (436597014492580191793334350048671093292406324933 / 125713786491693196178216804649738923184000000000000 : ℝ) * t^2 * (3*v*(1-v)^2) +
      (26050231317761999874936659365258807105580578517 / 5238074437153883174092366860405788466000000000000 : ℝ) * t^2 * (3*v^2*(1-v)) +
      (490836640187141139201363435494081 / 51739998688703013255159800000000000 : ℝ) * t^2 * v^3 := by
  norm_num [F, J, D, P, c, kappa0, theta, h, lx, ly, M, ell, b]
  <;> ring

theorem bernstein_margin_0 {t v : ℝ} (ht : 0 ≤ t) (ht1 : t ≤ 1)
    (hv : 0 ≤ v) (hv1 : v ≤ 1) :
    (5 / 1000000000000 : ℝ) < F (t / 4) (v / 2) := by
  have ht' : 0 ≤ 1 - t := sub_nonneg.mpr ht1
  have hv' : 0 ≤ 1 - v := sub_nonneg.mpr hv1
  rw [bernstein_identity_0]
  repeat' apply lt_of_lt_of_le ?_ (le_add_of_nonneg_right (by positivity))
  norm_num

theorem bernstein_identity_1 (t v : ℝ) :
    F (1 / 4 + t / 12) (v / 2) = (723 / 1000000 : ℝ) +
      (32073457698117007637408336919739918878634835737 / 8380919099446213078547786976649261545600000000000 : ℝ) * (1 - t)^2 * (1-v)^3 +
      (436597014492580191793334350048671093292406324933 / 125713786491693196178216804649738923184000000000000 : ℝ) * (1 - t)^2 * (3*v*(1-v)^2) +
      (26050231317761999874936659365258807105580578517 / 5238074437153883174092366860405788466000000000000 : ℝ) * (1 - t)^2 * (3*v^2*(1-v)) +
      (490836640187141139201363435494081 / 51739998688703013255159800000000000 : ℝ) * (1 - t)^2 * v^3 +
      (7619414589854362911548147217669625875670231207 / 6984099249538510898789822480541051288000000000000 : ℝ) * (2*t*(1-t)) * (1-v)^3 +
      (307821446778246608989470839579004803253149079743 / 377141359475079588534650413949216769552000000000000 : ℝ) * (2*t*(1-t)) * (3*v*(1-v)^2) +
      (1162267986303927538078926888615291677223663921851 / 377141359475079588534650413949216769552000000000000 : ℝ) * (2*t*(1-t)) * (3*v^2*(1-v)) +
      (19521927060226671804524684988239217 / 2069599947548120530206392000000000000 : ℝ) * (2*t*(1-t)) * v^3 +
      (1957369769822342496205129327753385962904743 / 10476148874307766348184733720811576932000000000000 : ℝ) * t^2 * (1-v)^3 +
      (23836653191300606196617258606783025038698428079 / 47142669934384948566831301743652096194000000000000 : ℝ) * t^2 * (3*v*(1-v)^2) +
      (4979138815919337230852686938637485594258525967 / 1109239292573763495690148276321225792800000000000 : ℝ) * t^2 * (3*v^2*(1-v)) +
      (195711799436668976067680505579888991 / 13969799645949813578893146000000000000 : ℝ) * t^2 * v^3 := by
  norm_num [F, J, D, P, c, kappa0, theta, h, lx, ly, M, ell, b]
  <;> ring

theorem bernstein_margin_1 {t v : ℝ} (ht : 0 ≤ t) (ht1 : t ≤ 1)
    (hv : 0 ≤ v) (hv1 : v ≤ 1) :
    (5 / 1000000000000 : ℝ) < F (1 / 4 + t / 12) (v / 2) := by
  have ht' : 0 ≤ 1 - t := sub_nonneg.mpr ht1
  have hv' : 0 ≤ 1 - v := sub_nonneg.mpr hv1
  rw [bernstein_identity_1]
  repeat' apply lt_of_lt_of_le ?_ (le_add_of_nonneg_right (by positivity))
  norm_num

theorem continuous_margin {δ y : ℝ} (hδ : 0 ≤ δ)
    (hy : 0 ≤ y) (hy1 : y ≤ 1 / 2) :
    (5 / 1000000000000 : ℝ) < F δ y := by
  by_cases hd0 : δ ≤ 1 / 4
  · have hh := bernstein_margin_0 (t := 4 * δ) (v := 2 * y)
      (by linarith) (by linarith) (by linarith) (by linarith)
    convert hh using 1 <;> congr 1 <;> ring
  · by_cases hd1 : δ ≤ 1 / 3
    · have hh := bernstein_margin_1 (t := 12 * (δ - 1 / 4)) (v := 2 * y)
        (by linarith) (by linarith) (by linarith) (by linarith)
      convert hh using 1 <;> congr 1 <;> ring
    · exact near_margin (by linarith) hy

theorem denominator_bounds {δ x : ℝ}
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5 / 6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1 / 2) :
    (25 / 39 : ℝ) ≤ J δ x ∧ J δ x ≤ 5 / 2 := by
  have bounds : (10 / 13 : ℝ) ≤ P x ∧ P x ≤ D x ∧ D x ≤ 3 := by
    norm_num [P, D, c, kappa0, theta]
    refine ⟨?_, ?_, hx0⟩ <;>
      nlinarith [sq_nonneg (x - 1 / 2), mul_nonneg hx0 (sub_nonneg.mpr hx1)]
  have hweight : 0 ≤ 5 / 6 - δ := by linarith
  have hl0 := mul_le_mul_of_nonneg_left (bounds.1.trans bounds.2.1) hweight
  have hl1 := mul_le_mul_of_nonneg_left bounds.1 hd0
  have hu0 := mul_le_mul_of_nonneg_left bounds.2.2 hweight
  have hu1 := mul_le_mul_of_nonneg_left (bounds.2.1.trans bounds.2.2) hd0
  dsimp [J]
  constructor <;> nlinarith

theorem F_E_identity {δ x : ℝ} (hj : J δ x ≠ 0) :
    F δ (1 / 2 - x) = -J δ x * E δ x := by
  simp only [F, E, sub_sub_cancel]
  field_simp
  <;> ring

/-- Exact strict saving over the entire closed rectangle, including its boundary. -/
theorem endpoint_saving {δ x : ℝ} (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5 / 6)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1 / 2) :
    E δ x < -(2 / 1000000000000 : ℝ) := by
  have hj := denominator_bounds hd0 hd1 hx0 hx1
  have hjpos : 0 < J δ x := by linarith [hj.1]
  have hf := continuous_margin hd0 (show 0 ≤ 1 / 2 - x by linarith)
    (show 1 / 2 - x ≤ 1 / 2 by linarith)
  rw [F_E_identity hjpos.ne'] at hf
  nlinarith [hj.2]

/-- Dynamic-kappa count loss and the extension to h+zeta preserve a common saving. -/
theorem post_extension_saving {δ x Δ : ℝ} (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5 / 6)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1 / 2) (hΔ : 0 ≤ Δ) :
    E δ x + h * Δ / 4 - Δ + 2 * zeta < -(1 / 1000000000000 : ℝ) := by
  have hh : h < (82 / 100 : ℝ) := by norm_num [h, lx, M, b, ell, theta]
  have hprod := mul_nonneg hΔ (show 0 ≤ 1 - h / 4 by linarith)
  have he := endpoint_saving hd0 hd1 hx0 hx1
  norm_num [zeta] at *
  nlinarith

end
end QRH.Certificate
