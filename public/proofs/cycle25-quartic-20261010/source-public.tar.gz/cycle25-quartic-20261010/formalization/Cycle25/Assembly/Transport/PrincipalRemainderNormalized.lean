/- Adapted from Cycle25.Transport weighted upstream PR6 and OpenAI/math; Apache-2.0 attribution retained. -/
import Cycle25.Assembly.Transport.GeometryFacts
import Cycle25.Assembly.Transport.PrincipalRemainderPhysicalBounds
import Cycle25.Assembly.Transport.PrincipalRemainderResidueActual
import Cycle25.Assembly.Transport.PrincipalRemainderRayThresholds
import OAI.NumberTheory.DirichletL.Detector.PrincipalNormalized
noncomputable section
open scoped Classical BigOperators Topology ContDiff
open Complex Filter
namespace Cycle25.Transport.PrincipalNormalized
open OAI OAI.SevenEighths OAI.SevenEighths.ProbePrincipalNormalized
open HeckeFamily ProbePhysical CompletedGauss ProbeFiniteProductBounds
open PrincipalMellinResidues PrincipalSignalComparison ProbePrincipalResidueActual ProbeRaySlots
open Cycle25.Transport.PrincipalResidueActual Cycle25.Transport.PrincipalRaySlots
local notation "Id" => Ideal HeckeFamily.O

lemma normalized_error (A R F N : ℂ) (c d v : ℝ)
    (hc : 0 ≤ c) (hA : ‖A-R‖ ≤ c) (hN : ‖N⁻¹‖ ≤ v)
    (hR : ‖R/N-F‖ ≤ d) : ‖A/N-F‖ ≤ c*v+d := by
  calc
    _ = ‖(A-R)*N⁻¹+(R/N-F)‖ := by congr 1; simp only [div_eq_mul_inv];ring
    _  ≤  ‖(A-R)*N⁻¹‖+‖R/N-F‖ := norm_add_le _ _
    _  ≤  c*v+d := by rw [norm_mul];gcongr

theorem actual_ray_principal_comparison {K : ℕ}
    (M : Id) [NeZero M] [Finite (HeckeFamily.O ⧸ M)]
    (H : Subgroup (HeckeFamily.O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M ≤ H)
    (η : Character) (S : Finset Id) (hS : SourceExclusions S)
    (c d B ellMin : ℝ) (hc : 0<c) (hd : c ≤ d) (hB : 0 ≤ B) (hmin : 0<ellMin)
    (slotEll : Fin K→ℝ) (hell : ∀j,ellMin ≤ slotEll j) (hdis : Function.Injective slotEll)
    (hsum : (∑j,slotEll j)=ell)
    (W : Fin K→ℝ→ℝ) (hW : ∀j,ContDiff ℝ ∞ (W j))
    (hcompact : ∀j,HasCompactSupport (W j))
    (hsupp : ∀j,Function.support (W j)⊆Set.Ioo c d)
    (hWbounds : ∀j y,0 ≤ W j y ∧ W j y ≤ B) (hne : ∀j,W j≠0)
    (W0 W1 : SchwartzMap ℝ ℂ) (a0 b0 a1 b1 : ℝ) (ha0 : 0<a0) (ha1 : 0<a1)
    (hW0 : Function.support W0⊆Set.Icc a0 b0) (hW1 : Function.support W1⊆Set.Icc a1 b1)
    (hr0 : ∀y,(W0 y).im=0) (hr1 : ∀y,(W1 y).im=0)
    (hp0 : ∀y,0 ≤ (W0 y).re) (hp1 : ∀y,0 ≤ (W1 y).re) (hn0 : W0≠0) (hn1 : W1≠0)
    (e nu : ℝ) (he : 0<e) (hehi : e ≤ 1/1000) (hnu : 0<nu)
    (ha : theta <HeckeZeroSupremum.beta+e) (ha2 : HeckeZeroSupremum.beta+e ≤ 2) :
    letI : NeZero (∏p∈S,p) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
    ∃C : ℝ,0<C ∧ ∀ᶠZ : ℝ in atTop,
      let T := fun j=>pool (RayQuotient.identityClass M H) S c d (Z^(slotEll j))
      let normer := sourceResidueConstant W0 W1 (∏p∈S,p)*
        (Probe.principalScalar Finset.univ Z ell
          (slotMass T (residueWeights W (fun j=>Z^(slotEll j)))) : ℂ)
      normer≠0 ∧
      ‖(∑P:(∀j,T j),(∏j,(W j ((Ideal.absNorm (P j).val.val:ℝ)/Z^(slotEll j)):ℂ))*
        principalRowIntegral η S (fun j=>primaryGenerator (P j).val.val)
          W0 W1 (Z^(lx:ℝ)) (Z^(ly:ℝ)) Z)/normer-
        HeckeSignal.signal (η.excludePrimes S hS.prime) (sourceCorrection η S) (PrincipalSignal.signalShift) Z‖ ≤ 
      C*(Z^(HeckeZeroSupremum.beta-(4+b)/6-1/4000+nu)+
        Z^(HeckeZeroSupremum.beta-(4+b)/6+e-(theta )*ellMin)) := by
  let : NeZero (∏p∈S,p) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
  obtain ⟨C0,hC0,hrem⟩ := Cycle25.Transport.PrincipalPhysical.physical_principal_residue_remainder
    η S hS c d B hc hd hB W0 W1 a0 b0 a1 b1 ha0 ha1 hW0 hW1 e he hehi ha ha2 (K:=K)
  obtain ⟨D,hD,hres⟩ := Cycle25.Transport.PrincipalResidueActual.normalized_actual_window_residue S hS η ha ha2 (by linarith [Cycle25.Transport.theta_bounds]) (Finset.univ : Finset (Fin K))
  let cs := sourceResidueConstant W0 W1 (∏p∈S,p)
  let C := C0/e*‖cs⁻¹‖+D*c^(-(theta :ℝ))+1
  refine ⟨C,by dsimp [C];positivity,?_⟩
  have hpos (j : Fin K) : tsupport (W j)⊆Set.Ioi 0 := by
    apply subset_trans (closure_minimal (Set.Subset.trans (hsupp j) Set.Ioo_subset_Icc_self) isClosed_Icc)
    intro y hy; exact lt_of_lt_of_le hc hy.1
  filter_upwards [Cycle25.Transport.PrincipalRaySlots.power_pool_thresholds (RayQuotient.identityClass M H) S η c d ellMin hc hd hmin slotEll hell,
    OAI.SevenEighths.ProbeRaySlots.power_ray_mass_and_normalizer M H hH S W c d hc hd hsupp hW hcompact hpos
      (fun j y=>(hWbounds j y).1) hne slotEll (fun j=>hmin.trans_le (hell j)) nu hnu,
    power_pool_tuples_eventually_injective (RayQuotient.identityClass M H) S
      (fun _=>c) (fun _=>d) slotEll (fun _=>hc) (fun _=>hd) hdis] with Z hthreshold hmass htuple
  rcases hthreshold with ⟨hZ,h480,hsmall,hslot,hpool⟩
  have hZ0 : 0<Z := by linarith [Cycle25.Transport.theta_bounds]
  let T := fun j=>pool (RayQuotient.identityClass M H) S c d (Z^(slotEll j))
  let normer := cs*(Probe.principalScalar Finset.univ Z ell
    (slotMass T (residueWeights W (fun j=>Z^(slotEll j)))) : ℂ)
  have hr := hres W0 W1 a0 b0 a1 b1 ha0 ha1 hW0 hW1 hr0 hr1 hp0 hp1 hn0 hn1
    T W (fun j=>Z^(slotEll j)) (c*Z^ellMin) (Z^(ly:ℝ)) Z h480 hsmall
    (fun j _ p _=>(hWbounds j _).1) (fun j _ p hp=>(hpool j p hp).1)
    (fun j _ p hp=>(hpool j p hp).2.1) (fun j _=>hmass.1 j) hZ
  dsimp only at hr ⊢
  simp only [PrincipalSignal.signalShift, neg_div, ← sub_eq_add_neg] at hr ⊢
  refine ⟨hr.1,?_⟩
  have hraw := hrem slotEll hsum W hWbounds (fun j=>Set.Subset.trans (hsupp j) Set.Ioo_subset_Icc_self)
    T (fun j p hp=>(hpool j p hp).2.2) htuple Z hZ (fun j=>(hslot j).1) (fun j=>(hslot j).2)
  have hinv : ‖normer⁻¹‖ ≤ ‖cs⁻¹‖*Z^nu := by
    dsimp only [normer]
    rw [mul_inv_rev,norm_mul,←Complex.ofReal_inv,norm_real]
    simpa only [hsum,Real.norm_eq_abs,mul_comm] using mul_le_mul_of_nonneg_left hmass.2 (norm_nonneg cs⁻¹)
  have hh := normalized_error _ _ _ normer _ _ _ (by positivity) hraw hinv hr.2.2
  have hpw : (c*Z^ellMin)^(-(theta :ℝ))=c^(-(theta :ℝ))*Z^(-(theta :ℝ)*ellMin) := by
    rw [Real.mul_rpow hc.le (Real.rpow_nonneg hZ0.le _),←Real.rpow_mul hZ0.le]
    congr 2;ring
  have heq1 : (C0/e*Z^(HeckeZeroSupremum.beta-(4+b)/6-1/4000))*(‖cs⁻¹‖*Z^nu)=
      (C0/e*‖cs⁻¹‖)*Z^(HeckeZeroSupremum.beta-(4+b)/6-1/4000+nu) := by
    rw [Real.rpow_add hZ0];ring
  have heq2 : D*Z^(HeckeZeroSupremum.beta+e-(4+b)/6)*(c*Z^ellMin)^(-(theta :ℝ))=
      (D*c^(-(theta :ℝ)))*Z^(HeckeZeroSupremum.beta-(4+b)/6+e-(theta )*ellMin) := by
    rw [hpw]
    rw [show HeckeZeroSupremum.beta-(4+b)/6+e-(theta )*ellMin=
      (HeckeZeroSupremum.beta+e-(4+b)/6)+(-(theta :ℝ)*ellMin) by ring,Real.rpow_add hZ0]
    ring
  apply hh.trans
  rw [heq1,heq2]
  have h1 : C0/e*‖cs⁻¹‖ ≤ C := by
    dsimp [C]
    have : 0 ≤ D*c^(-(theta :ℝ)) := by positivity
    linarith
  have h2 : D*c^(-(theta :ℝ)) ≤ C := by
    dsimp [C]
    have : 0 ≤ C0/e*‖cs⁻¹‖ := by positivity
    linarith
  calc
    _  ≤  C*Z^(HeckeZeroSupremum.beta-(4+b)/6-1/4000+nu)+
        C*Z^(HeckeZeroSupremum.beta-(4+b)/6+e-(theta )*ellMin) := by gcongr
    _ = _ := by ring
end Cycle25.Transport.PrincipalNormalized
end

